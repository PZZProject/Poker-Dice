var searchData=
[
  ['tablica_5fwynikow',['tablica_wynikow',['../_kosci_01robocze_8cpp.html#a7df1700a92c96022252268c445a777c9',1,'Kosci robocze.cpp']]]
];
