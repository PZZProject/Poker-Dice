var searchData=
[
  ['autosave',['autosave',['../_kosci_01robocze_8cpp.html#a163397437305d6dbcd4f1f87e9ac58af',1,'Kosci robocze.cpp']]]
];
