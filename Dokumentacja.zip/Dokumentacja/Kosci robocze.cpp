
#include<stdio.h>
#include<stdlib.h>
#include<time.h>

/**
 * \brief Funkcja losowania
 *
 * Funkcja ta losuje 5 liczb z zakresu 1-6 odpowiadaj�cych warto�ci oczek na ko�ciach. Zapisywane s� tymczasowo do tablicy "rzut".
 */
void losowanie(int rzut[]){
	for(int i=0;i<5;i++)
	{
		rzut[i]=rand()%6+1;
	}

}


/**
 * \brief Funkcja wymiany
 *
 * Funkcja ta losuje losowe liczby z zakresu 1-6 dla wybranych element�w tablicy "rzut". Innymi s�owy, gracz wymienia ustalone przez siebie ko�ci. 
 * \param[in] n Ilosc wymienianych kosci
 * \param[in,out] wyraz Kosci kt�re chcemy wymienic. Moze zawierac do 5 znak�w, dlatego jest typu char. Litera 'x' oznacza, i� nie chcemy zmienia� ustawienia. 
 */

void wymiana_kosci(int n,int rzut[], char wyraz[]){

	for(int i=0;i<5;i++)
	{
		wyraz[i]='x';
	}
	printf("\nKtore kosci chcesz wymienic?(x-zadna)\n");
	scanf("%s",wyraz);
	
	if(wyraz[0]!='x'){
		for(int i=0;i<n;i++)
		{
			if (wyraz[i]=='1') { rzut[0]=rand()%6+1;}
			if (wyraz[i]=='2') { rzut[1]=rand()%6+1;}
			if (wyraz[i]=='3') { rzut[2]=rand()%6+1;}
			if (wyraz[i]=='4') { rzut[3]=rand()%6+1;}
			if (wyraz[i]=='5') { rzut[4]=rand()%6+1;}
		}
	}
}

/**
 * \brief Funkcja Wypisz
 *
 * Wypisuje liczby oczek w danym rzucie.
 */

void wypisz(int rzut[]){
	for(int i=0;i<5;i++)
		{
			printf("%d ",rzut[i]);
		}
}


/**
 * \brief Funkcja formularza
 *
 * Tutaj zapisywane s� punkty, kt�re dany gracz uzyska� oraz obliczana ich ilosc.
 * \param[in,out] tab Tablica z wynikami danego gracza.
 * \param[in,out] tab_obraz Tablica okreslajaca, czy dana kategoria by�a juz wczesniej wykorzystana ( 0 - nie, 1 - tak ). 
 * \param[in] a Wybrana kategoria
 * \param[in,out] kosci Tablica ta zlicza dane wystapienia oczek wedle pozycji w tabeli ( kosci[1] - liczba kosci o liczbie oczek 1 itd.. ). U�atwia liczenie punktacji.
 *
 */
 
 
void tablica_wynikow(int tab[],int tab_obraz[],char a, int kosci[]){
	
	int zm_pom1, zm_pom2;	
	PRZYDZIELANIE:
	switch(a){
		case 1:
			if(tab_obraz[0]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				tab[0]=1*kosci[1];
				tab_obraz[0]=1;
			}
			break;
		case 2:
			if(tab_obraz[1]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				tab[1]=2*kosci[2];
				tab_obraz[1]=1;
			}
			break;
		case 3:
			if(tab_obraz[2]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				tab[2]=3*kosci[3];
				tab_obraz[2]=1;
			}
			break;
		case 4:
			if(tab_obraz[3]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				tab[3]=4*kosci[4];
				tab_obraz[3]=1;
			}
			break;
		case 5:
			if(tab_obraz[4]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				tab[4]=5*kosci[5];
				tab_obraz[4]=1;
			}
			break;
		case 6:
			if(tab_obraz[5]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				tab[5]=6*kosci[6];
				tab_obraz[5]=1;
			}
			break;
		case 7:									// trojka
			if(tab_obraz[6]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				for(int i=1;i<7;i++){
					if(kosci[i]==3){ tab[6]=kosci[1]+(2*kosci[2])+(3*kosci[3])+(4*kosci[4])+(5*kosci[5])+(6*kosci[6]);	}
					if(kosci[i]==5 && tab_obraz[11]>0){tab[6]=kosci[1]+(2*kosci[2])+(3*kosci[3])+(4*kosci[4])+(5*kosci[5])+(6*kosci[6]); }
				}
				tab_obraz[6]=1;
			}
			break;
		case 8:									// kareta
			if(tab_obraz[7]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				for(int i=1;i<7;i++){
					if(kosci[i]==4){ tab[7]=kosci[1]+(2*kosci[2])+(3*kosci[3])+(4*kosci[4])+(5*kosci[5])+(6*kosci[6]);	}
					if(kosci[i]==5 && tab_obraz[11]>0){tab[7]=kosci[1]+(2*kosci[2])+(3*kosci[3])+(4*kosci[4])+(5*kosci[5])+(6*kosci[6]); }
				}
				tab_obraz[7]=1;
			}
			break;
		case 9:									// full
			if(tab_obraz[8]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				zm_pom1=0;
				zm_pom2=0;
				for(int i=1;i<7;i++){
					if(kosci[i]==3){ zm_pom1=1;	}
					if(kosci[i]==2){ zm_pom2=1;	}
					if(kosci[i]==5 && tab_obraz[11]>0){tab[8]=25; }
				}
				if(zm_pom1==1 && zm_pom2==1){ tab[8]=25;	}
				tab_obraz[8]=1;
			}
			break;
		case 10:								// maly strit
			if(tab_obraz[9]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				if(kosci[1]>0 && kosci[2]>0 && kosci[3]>0 && kosci[4]>0){ tab[9]=30;}
				if(kosci[2]>0 && kosci[3]>0 && kosci[4]>0 && kosci[5]>0){ tab[9]=30;}
				if(kosci[3]>0 && kosci[4]>0 && kosci[5]>0 && kosci[6]>0){ tab[9]=30;}
				for(int i=1;i<7;i++){
					if(kosci[i]==5 && tab_obraz[11]>0){tab[9]=30; }
				}
				tab_obraz[9]=1;
			}
			break;
		case 11:								// duzy strit
			if(tab_obraz[10]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				if(kosci[1]>0 && kosci[2]>0 && kosci[3]>0 && kosci[4]>0 && kosci[5]>0){ tab[10]=40;}
				if(kosci[2]>0 && kosci[3]>0 && kosci[4]>0 && kosci[5]>0 && kosci[6]>0){ tab[10]=40;}
				for(int i=1;i<7;i++){
					if(kosci[i]==5 && tab_obraz[11]>0){tab[10]=30; }
				}
				tab_obraz[10]=1;
			}
			break;
		case 12:								// general
			if(tab_obraz[11]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				for(int i=1;i<7;i++){
					if(kosci[i]==5){ tab[11]=50;}
				}
				tab_obraz[11]=1;
			}
			break;
		case 13:								// szansa
			if(tab_obraz[12]>0){
				printf("Juz wykozystales ta mozliwosc. Podaj inna: ");
				scanf("%d",&a);
				goto PRZYDZIELANIE;
			} 
			else 
			{
				tab[12]=kosci[1]+(2*kosci[2])+(3*kosci[3])+(4*kosci[4])+(5*kosci[5])+(6*kosci[6]);
				for(int i=1;i<7;i++){
					if(kosci[i]==5 && tab_obraz[11]>0){tab[7]=kosci[1]+(2*kosci[2])+(3*kosci[3])+(4*kosci[4])+(5*kosci[5])+(6*kosci[6]); }
				}
				tab_obraz[12]=1;
			}
			break;
		default:
			printf("Zla opcja! Podaj inna: ");
			scanf("%d",&a);
			goto PRZYDZIELANIE;
			break;
	}
	
}

/**
 * \brief Wyswietlenie formularza
 *
 * Funkcja ta wyswietla punktacje danego gracza
 */
void wypisz_wyniki(int tab[]){
	printf("\n");
	printf("1. Jedynki:        %d\n",tab[0]);
	printf("2. Dwojki:         %d\n",tab[1]);
	printf("3. Trojki:         %d\n",tab[2]);
	printf("4. Czworki:        %d\n",tab[3]);
	printf("5. Piatki:         %d\n",tab[4]);
	printf("6. Szostki:        %d\n",tab[5]);
	printf("\n7. Trojka:         %d\n",tab[6]);
	printf("8. Kareta:         %d\n",tab[7]);
	printf("9. Full:           %d\n",tab[8]);
	printf("10. Maly strit:    %d\n",tab[9]);
	printf("11. Duzy strit:    %d\n",tab[10]);
	printf("12. General:       %d\n",tab[11]);
	printf("13. Szansa:        %d\n",tab[12]);
	
}

/**
 * \brief Sumowanie punktacji
 *
 * Tutaj nastepuje sumowanie punktow i premii. Na poczatku sprawdza, czy jest premia w gornej czesci, dopiero potem nastepuje faktyczne zliczanie.
 */
 
int sumowanie(int tab[]){
	int suma;
	suma=0;
	for(int i=0;i<6;i++){
	 	suma=suma+tab[i];
	}
	if(suma>62){ suma=35;} else { suma=0; }
	for(int i=0;i<13;i++){
		suma=suma+tab[i];
	}
	
	return suma;
	
}

/**
 * \brief Autozapis
 *
 * Funkcja autozapisu. Zapisuje do pliku 4 wiersze: punkty oraz zajetosc ( czy opcja byla juz wybrana ) dla kazdego z 2 graczy ).
 */
 
void autosave(int tab_1[],int tab_1_obraz[],int tab_2[],int tab_2_obraz[]){
	
	FILE *strumien2;
	strumien2=fopen("save.txt","wt");
	for(int i=0;i<13;i++){
	fprintf (strumien2,"%d ",tab_1[i]);
	}	
	fprintf(strumien2,"\n");
	for(int i=0;i<13;i++){
	fprintf (strumien2,"%d ",tab_1_obraz[i]);
	}	
	fprintf(strumien2,"\n");
	for(int i=0;i<13;i++){
	fprintf (strumien2,"%d ",tab_2[i]);
	}
	fprintf(strumien2,"\n");
	for(int i=0;i<13;i++){
	fprintf (strumien2,"%d ",tab_2_obraz[i]);
	}	
	fclose(strumien2);

}

/**
 * \brief Wczytywanie
 *
 * Wczytywanie danych z pliku do gry.
 *
 */
 
void wczytaj(int tab_1[],int tab_1_obraz[],int tab_2[],int tab_2_obraz[]){
int n,k;
k=0;	
FILE *strumien;
strumien=fopen("save.txt","rt");
if(strumien==NULL){
	printf("Wczytanie nie powiod�o si�. Gra rozpocznie si� od nowa.");
	getchar();
	for(k=0;k<13;k++){
		tab_1[k]=0;
		tab_1_obraz[k]=0;
		tab_2[k]=0;
		tab_2_obraz[k]=0;
	}
}
else
{

while (fscanf(strumien, "%d", &n) != EOF)
{
	if(k<13){tab_1[k]=n;}
		if(k<26){tab_1_obraz[k-13]=n;}
			if(k<39){tab_2[k-26]=n;}
				if(k<52){tab_2_obraz[k-39]=n;}
	k=k+1;
}
}
fclose(strumien);

}

/**
 * \brief Samouczek
 *
 * Samouczek, po prostu, z gory ustalonym przebiegiem.
 */
 
void samouczek(){
	char c;
	int d;
	system("cls");
	printf(" Witamy serdecznie w samouczku !\n\n");
	printf("Samouczek ma za zadanie wprowadzic Cie w zasady obsugi niniejszej produkcji.\n");
	printf("\nP.s. Gra jest w fazie BETA.\n");
	printf("Wykonuj polecenia zgodnie z wytycznymi. Wszelkie problemy prosze zglaszac administratorowi.\n");
	printf("\nKliknij ENTER, aby kontynuowac.");
	getchar();
	system("cls");
	printf("Gra KOSCI przeznaczona jest dla 2 graczy. Kazdy z nich wykonuje ruchy w swojej turze.\n");
	printf("Rozgrywka trwa 13 tur, po ktorych nastepuje podliczenie zebranych punktow i ogloszenie wynikow.\n");
	printf("Zwyciezca zostaje gracz, ktory zebral wieksza ilosc punktow.");
	printf("Wszelkie zasady gry w kosci mozesz znalezc na niniejszych stronach:\n");
	printf("www.wikipedia.pl\n");
	printf("www.kurnik.pl\n");
	printf("\n\n Kliknij ENTER, aby kontynuowac.");
	getchar();
	system("cls");
	printf("Ponizej znajduja sie liczbym ktore gracz 1 wylosowal.\n");
	printf("Teraz gracz moze ponownie rzucic koscmi, ktore uznal za stosowne do wymiany.\n");
	printf("Hmm... Ponizsze zestawienie nie jest najlepsze.\n");
	printf("Sprobuj zamienic 2,3 i 5 kosc, klikajac poszczegolne cyfry na klawiaturze, a nastepnie zatwierdz ENTERem.");
	printf("\n\n\nGRACZ 1 !!! \n\n");
	printf("Kosci: 6 2 4 6 5\n");
	printf("Ktore kosci chcesz wymienic?(x-zadna)\n");
	SKOK1:	
	scanf("%d",&d);	
	if(d!=235){ printf("\nZle! Nie zmieniles liczb, o ktore Cie proszono. Popraw.\n"); goto SKOK1;}
	system("cls");
	printf("Gratulacje!!! Poprawie wykonales polecenie.\n");
	printf("Spojrzmy teraz na nowe rozdanie... Masz fulla.\n");
	printf("To bardzo dobre rozdanie. Zachowajmy je.\n");
	printf("Kliknij 'x', aby zachowac obecne rozdanie.\n");
	printf("\n\n\nGRACZ 1 !!! \n\n");
	printf("Kosci: 6 4 6 6 4\n");
	printf("Ktore kosci chcesz wymienic?(x-zadna)\n");
		SKOK2:
	scanf("%c",&c);
	scanf("%c",&c);
	if(c!='x'){ printf("\nZle! Kliknij odpowiedni klawisz\n."); goto SKOK2;}
	system("cls");
	printf("Doskonale!!!\n");
	printf("Popatrz! Nizej zostala ukazana tabela Twoich wynikow. Jest to 1 tura, wiec nie masz zadnych pkt.\n");
	printf("Ale mozemy to teraz zmienic. Wybierz odpowiednia rubryke dla swojej figury (9).\n");
	printf("\n");
	printf("Wyniki GRACZA 1:\n\n");
	printf("Kosci: 6 4 6 6 4\n");
	printf("1. Jedynki:        0\n");
	printf("2. Dwojki:         0\n");
	printf("3. Trojki:         0\n");
	printf("4. Czworki:        0\n");
	printf("5. Piatki:         0\n");
	printf("6. Szostki:        0\n");
	printf("\n7. Trojka:         0\n");
	printf("8. Kareta:         0\n");
	printf("9. Full:           0\n");
	printf("10. Maly strit:    0\n");
	printf("11. Duzy strit:    0\n");
	printf("12. General:       0\n");
	printf("13. Szansa:        0\n");
	printf("\nWybierz pozycje: ");
	SKOK3:
	scanf("%d",&d);	
	if(d!=9){ printf("\nZle! Kliknij odpowiedni klawisz.\n"); goto SKOK3;}
	system("cls");
	printf("Wysmienicie! Na tym kroku zakonczyla sie Twoja tura. Kolejny gracz wykonuje kroki analogicznie.\n");
	printf("Nie musimy juz tego powtarzac.\n");
	printf("Pamietaj, ze nie mozesz uzyc ponownie rubryki, ktora juz wybrales wczesniej.\n");
	printf("Kazda opcja jest dostepna tylko 1 raz!\n");
	printf("\nPo 13 turach nastepuje podliczenie pkt, ktore zebrales i porownanie wynikow.\n");
	printf("Nie musisz tez przejmowac sie o przerwanie gry.\n");
	printf("Co ture wykonywany jest autozapis, ktory pozwoli Ci wznowic nie dokonczone gre.\n");
	printf("\nMilej zabawy!.\n");
	printf("\n Kliknij ENTER, aby kontynuowac.");
	getchar();
		getchar();
	
	
	
	
}

//----------------------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------------------

/**
 * \brief Przebieg gry
 *
 * Wpierw nastepuje inicjalizacja tablic.
 * \attention Uzylem tutaj wskaznikow, ale mozna je zamienic na zwykle tablice. Chcialem w zarysie pokazac jak ma to wygladac.
 *            Dlatego dla ulatwienia uzylem wskaznikow, ale nic nie stoi na przeszkodzie by zamienic je na zwykle tablice, nawet globalne, by nie odnosic sie do funkcji.
 *            W polowie przypomnialo mi sie, ze nie moge urzywac wskaznikow, moj fail. Jezeli bedzie to stanowic klopot przy zamianie na globalne, to przerobie.
 */
 
int main(){
	int *rzut;
	rzut=(int *)malloc(sizeof(int)*5);
	int *kosci;
	kosci=(int *)malloc(sizeof(int)*7);
	int *tab_1;
	tab_1=(int *)malloc(sizeof(int)*13);
		int *tab_1_obraz;
		tab_1_obraz=(int *)malloc(sizeof(int)*13);
	int *tab_2;
	tab_2=(int *)malloc(sizeof(int)*13);
		int *tab_2_obraz;
		tab_2_obraz=(int *)malloc(sizeof(int)*13);
	char wyraz[5];
	int i,tura,n,k;
	char a,z;
	
	START:
	system("cls");
	printf("\n                                 ! GRA KOSCI !\n");
	printf("\n                                 1. Nowa gra");
	printf("\n                                 2. Wczytaj");
	printf("\n                                 3. Samouczek");
	printf("\n                                 4. Wyjdz");
	printf("\n\n                               Co chcesz wybrac?");
	printf("\n                                      ");
	scanf("%c",&z);
	getchar();
	srand(time(NULL));
if(z=='4'){ goto KONIEC;}
if(z=='1'){

	tura=0;	
	for(i=0;i<7;i++){
		kosci[i]=0;
	}
		for(i=0;i<13;i++){
		tab_1[i]=0;
		tab_1_obraz[i]=0;
		tab_2[i]=0;
		tab_2_obraz[i]=0;
	}
}
if(z=='2'){
wczytaj(tab_1,tab_1_obraz,tab_2,tab_2_obraz);	
	for(i=0;i<7;i++){
		kosci[i]=0;
	}
	/** 
	* brief Maly problem
	* 
	* Nie potrafi zliczac poprawnie tury po wczytaniu. Powinien sumowac zajetosc tabeli ( ile bylo wybranych opcji, to taka tura ).
	*/
	for(int i=0;i<13;i++){
		tura=tura+tab_2_obraz[i];
	}
}

if(z=='3'){
	samouczek();
	goto START;


}
	while(tura!=13){

		system("cls");
		printf("TURA %d\n\nGRACZ 1 !!! \n",(tura+1));
		losowanie(rzut);
		printf("Kosci: ");
		wypisz(rzut);
		wymiana_kosci(5,rzut,wyraz);
		printf("\n");
		if(wyraz[0]!='x'){
			printf("Kosci: ");
			wypisz(rzut);
			wymiana_kosci(5,rzut,wyraz);
			printf("\n");
		}
		printf("\n");
	
	
		for(i=0;i<5;i++){
			kosci[rzut[i]]=kosci[rzut[i]]+1;
		}
	
		system("cls");
		printf("Wyniki GRACZA 1:\n\n");
		printf("Kosci: ");
		wypisz(rzut);
		wypisz_wyniki(tab_1);
		printf("\nWybierz pozycje: ");
		scanf("%d",&a);	
	
		tablica_wynikow(tab_1,tab_1_obraz,a,kosci);
	
	
	
	
		system("cls");
		printf("TURA: %d\n\nGRACZ 2 !!! \n",(tura+1));
		losowanie(rzut);
		printf("Kosci: ");
		wypisz(rzut);
		wymiana_kosci(5,rzut,wyraz);
		printf("\n");
		if(wyraz[0]!='x'){
			printf("Kosci: ");
			wypisz(rzut);
			wymiana_kosci(5,rzut,wyraz);
			printf("\n");
		}
		printf("\n");
	
	
		for(i=0;i<5;i++){
			kosci[rzut[i]]=kosci[rzut[i]]+1;
		}

		system("cls");
		printf("Wyniki GRACZA 2:\n\n");
		printf("Kosci: ");
		wypisz(rzut);
		wypisz_wyniki(tab_2);
		printf("\nWybierz pozycje: ");
		scanf("%d",&a);	

		tablica_wynikow(tab_2,tab_2_obraz,a,kosci);
	
	
	
		tura=tura+1;
	
		autosave(tab_1,tab_1_obraz,tab_2,tab_2_obraz);
	}



	system("cls");
	printf("\nGRACZ 1 uzyskal %d pkt", sumowanie(tab_1));
	printf("\nGRACZ 2 uzyskal %d pkt", sumowanie(tab_2));



	KONIEC:
	free(rzut);
	free(kosci);
	free(tab_1);
	free(tab_1_obraz);
	free(tab_2);
	free(tab_2_obraz);
	getchar();
	return 0;
}
